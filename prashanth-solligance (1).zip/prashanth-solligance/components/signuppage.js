import React from "react"
import {useState} from "react"
import {View ,Text , Button , TextInput , StyleSheet} from "react-native"

function Home({navigation}){
 const [inputata , setinputdata ] = useState("")
 const [password , setpassword] = useState("")
 console.log(password)

  
  return(
    <View  style={styles.container}>
    <Text> SIGNUP PAGE</Text>
  
        <TextInput   style={styles.input} placeholder={'Username'}  value={inputata} onChangeText={(username) => setinputdata( username )}/>
        <TextInput   style={styles.input} placeholder={'Password'}  value={password} onChangeText={(username) => setpassword( username )} />
       
         <Button title={'signup'} style={styles.input} onPress={()=> navigation.navigate("login" , {
          
            usernameid:inputata ,
            userpasswordid:password
          })}
          />
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
  },
  input: {
    width: 200,
    height: 44,
    padding: 10,
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 10,
  },
});

export default Home