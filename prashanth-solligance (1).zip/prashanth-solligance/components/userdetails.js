import React from "react"
import {useState} from "react"
import {View ,Text , StyleSheet , Button} from "react-native"

function Profile({route, navigation }){
   const { userdetails } =route.params;
   const[datamap , setdatamap] = useState(userdetails )

   var deletehandle = (param)=>{
        let deletedata = datamap.filter((item)=>{
          return(
             item.userdatpass!== param
          )
        })
     setdatamap(deletedata)
      console.log(deletehandle)
   }

  
    
  let userdetailsview = datamap.map((item ,index)=>{
    return(
      <View style={styles.datawrapper}>
      <Text id={index}></Text> 
    <Text style={styles.userdata} key={index}>{item.userdataname}</Text>  
    <Text style={styles.userdata}>{item.userdatpass}</Text> 
    <Button onPress={()=>deletehandle(item.userdatpass)} title={"DELETE"} />
      </View>
    )
  })
   
  return(
    <View style= {styles.userwrapper}>
    <Text>{ userdetailsview }</Text>
    </View>
  )
}
const styles = StyleSheet.create({
  userwrapper:{
    width:"100%",
    height:"100%",
    display:"flex",
    flexDirection:"row",
    justifyContent:"center",
    alignItems:"center"
  },
  datawrapper:{
    width:"100%",
    display:"flex",
    flexDirection:"row",
    justifyContent:"center",
    alignItems:"center"
  },
  userdata:{
    margin:"20%",
    border:"black"
  }
});

export default Profile