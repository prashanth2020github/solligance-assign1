import React from "react"
import {useState} from "react"

import {View ,Text , TextInput , StyleSheet , Button} from "react-native"

function Detail({route, navigation}){
  const [inputata , setinputdata ] = useState("")
   const [password , setpassword] = useState("")
  

  const {  usernameid ,  userpasswordid } =route.params;
  var  userdetails = [
      {
        userdataname:usernameid,
        userdatpass:userpasswordid ,
        userid:1
       },
      
  ]


 var onloginfunhandle = ()=>{
  if(inputata== usernameid && password==userpasswordid){
    navigation.navigate("userdata" , {
         userdetails
       })
  }else{
    alert("INCORRECT USERNAME OR PASSWORD")
  }
  }

   console.log( userdetails)
  return(
    <View style={styles.container}>
    <TextInput   style={styles.input} placeholder={'Username'}  value={inputata} onChangeText={(username) => setinputdata( username )}/>
        <TextInput   style={styles.input} placeholder={'Password'}  value={password} onChangeText={(username) => setpassword( username )} />
         <Button title={'Login'} style={styles.input}  onPress = { onloginfunhandle}/>
        
    </View>
  )
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
  },
  input: {
    width: 200,
    height: 44,
    padding: 10,
    borderWidth: 1,
    borderColor: 'black',
    marginBottom: 10,
  },
});

export default Detail